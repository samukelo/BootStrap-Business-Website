<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>The COH - The Conglomerate Of Helpers</title>
    <meta name="description" content="Free Bootstrap Theme by BootstrapMade.com">
    <meta name="keywords" content="free website templates, free bootstrap themes, free template, free bootstrap, free website template">

	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans|Open+Sans|Raleway" rel="stylesheet">
	<link rel="stylesheet" href="css/flexslider.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body id="top" data-spy="scroll">
	<!--top header-->

	<header id="home">

		<section class="top-nav hidden-xs">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="top-left">

							<ul>
								<li><a href="https://www.facebook.com/thecohPtyLtd/" target="_blank"><i class="fa fa-facebook"  aria-hidden="true"></i></a></li>
								<li><a href="https://twitter.com/The_cohZA" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li><a href="https://www.linkedin.com/company/18020927" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
								<li><a href="https://github.com/theconglomerateofhelpers" target="_blank"><i class="fa fa-github" aria-hidden="true"></i></a></li>
								<li><a href="https://plus.google.com/u/0/b/113278069593191628272/113278069593191628272" target="_blank"><i class="fa fa-google" aria-hidden="true"></i></a></li>
							</ul>

						</div>
					</div>
				</div>
			</div>
		</section>

		<!--main-nav-->

		<div id="main-nav">

			<nav class="navbar">
				<div class="container">
             <div class="navbar-header">
             <a href="index.html"><img src="images/logo/logo.png" style="height:109px;width:250px;padding-top:0;"/></a>
							<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#ftheme">
							<span class="sr-only">Toggle</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>

					<div class="navbar-collapse collapse" id="ftheme">

						<ul class="nav navbar-nav navbar-right">
							<li><a href="index.html">home</a></li>
							<li><a href="about.html">about</a></li>
							<li><a href="services.html">services</a></li>
							<li><a href="contact-us.php" style="color:#C00010">contact</a></li>
							</ul>

					</div>
				</div>
			</nav>
		</div>
	</header>
<br><br>
	<!--contact form-->
	<div id="get-touch">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
					<div class="get-touch-heading">
						<h2>get in touch</h2>
						<p>Send A message from this page and get a follow-Back Fast</p>
					</div>
				</div>
			</div><br>

			<div class="content">
				<div class="col-md-4 col-sm-4">
			<h3>Contact Info</h3>
			<div class="space"></div>
			<p><i class="fa fa-map-marker fa-fw pull-left fa-2x"></i>Pretoria & Mpumalanga<br>
				We Here</p>
			<div class="space"></div>
			<a href="mailto:help@thecoh.co.za" style="text-decoration:none;color:#333333"><p><i class="fa fa-envelope-o fa-fw pull-left fa-2x"></i>help@thecoh.co.za</p></a>
			<div class="space"></div><br>
			<p><i class="fa fa-phone fa-fw pull-left fa-2x"></i>079 040 2893</p>
		</div>
	<div class="col-md-8 col-sm-8 ">

											 <form action="#" method="post" role="form" class="form contactForm">
												<div class="col-md-4">
														<div class="form-group">
																	<input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
																	<div class="validation"></div>
															</div>
												</div>
												<div class="col-md-4">
														<div class="form-group">
																	<input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
																	<div class="validation"></div>
															</div>
												</div>
												<div class="col-md-4">
														<div class="form-group">
																	<input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
																	<div class="validation"></div>
															</div>
												</div>
												<div class="col-md-12">
														<div class="form-group">
																	<textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
																	<div class="validation"></div>
															</div>
												</div>
												<div class="submit">
														<button class="btn btn-default" type="submit">Send Now</button>
												</div>
										</form>
</div>

<?php
if(isset($_POST['email'])) {

    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_to = "samukelomakofan@gmail.com";
    $email_subject = "I'm From The Website";

    function died($error) {
        // your error code can go here
        echo "We are very sorry, but there were error(s) found with the form you submitted. ";
        echo "These errors appear below.<br /><br />";
        echo $error."<br /><br />";
        echo "Please go back and fix these errors.<br /><br />";
        die();
    }


    // validation expected data exists
    if(!isset($_POST['name']) ||
        !isset($_POST['email']) ||
				!isset($_POST['subject']) ||
        !isset($_POST['message'])) {
        died('We are sorry, but there appears to be a problem with the form you submitted.');
    }

    $names = $_POST['name']; // required
    $email_from = $_POST['email']; // required
		$subject = $_POST['subject']; // required
    $message = $_POST['message']; // not required

    $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';

  if(!preg_match($email_exp,$email_from)) {
    $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
  }

    $string_exp = "/^[A-Za-z .'-]+$/";

  if(!preg_match($string_exp,$names)) {
    $error_message .= 'Your FullName you entered does not appear to be valid.<br />';
  }

  if(!preg_match($string_exp,$subject)) {
    $error_message .= 'The Subject you entered does not appear to be valid.<br />';
  }

  if(strlen($message) < 2) {
    $error_message .= 'The message you entered do not appear to be valid.<br />';
  }

  if(strlen($error_message) > 0) {
    died($error_message);
  }

    $email_message = "Form details below.\n\n";


    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }

		echo"<script>alert('Your Message Has Been Sent Enjoy The Rest Of Your Day');</script>";
			echo"<script>window.open('index.html','_self');</script>";


    $email_message .= "Full Names: ".clean_string($names)."\n";
    $email_message .= "subject: ".clean_string($subject)."\n";
    $email_message .= "Email: ".clean_string($email_from)."\n";
    $email_message .= "Comments: ".clean_string($message)."\n";

// create email headers
$headers = 'From: '.$email_from."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);
}
?>

								</div>
					</div>
			</div>
	</div>

	<!--footer-->
	<div id="footer" >
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<div class="footer-heading">
						<h3><span>about</span> us</h3>
						<p>We are, engineers, thinkers, innovators, intrepreneurs who love doing things that benefits businesses and human beings.</p>
					</div>
				</div>
				<div class="col-md-8">
					<div class="footer-heading">
					<h3 style="text-align: center">Follow us and like us on the famous platforms</h3>
				</div>
					<div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
						<a href="https://www.facebook.com/thecohPtyLtd/" target="_blank" style="padding-left:15px"><i class="fa fa-facebook fa-4x" style="color:#062add"  aria-hidden="true"></i></a>
						<a href="https://twitter.com/The_cohZA" target="_blank" style="padding-left:15px"><i class="fa fa-twitter fa-4x" style="color:#0d5896" aria-hidden="true"></i></a>
						<a href="https://www.linkedin.com/company/18020927" target="_blank" style="padding-left:15px"><i class="fa fa-linkedin fa-4x" style="color:#074577" aria-hidden="true"></i></a>
						<a href="https://github.com/theconglomerateofhelpers" target="_blank" style="padding-left:15px"><i class="fa fa-github fa-4x" style="color:#134e66" aria-hidden="true"></i></a>
						<a href="https://plus.google.com/u/0/b/113278069593191628272/113278069593191628272" target="_blank" style="padding-left:15px"><i class="fa fa-google fa-4x" style="color:#e20909" aria-hidden="true"></i></a>
					</div>
				</div>
			</div>
			<br>
			<center>
				&copy; The Conglomerate Of Helpers. All rights reserved
		</center>
		</div>
	</div>

<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.flexslider.js"></script>
	<script src="js/jquery.inview.js"></script>
	<script src="https://maps.google.com/maps/api/js?sensor=true"></script>
	<script src="js/script.js"></script>
	<script src="contactform/contactform.js"></script>

</body>
</html>
